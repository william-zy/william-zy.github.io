// DlgProxy.h : header file
//

#if !defined(AFX_DLGPROXY_H__73C59726_E576_4481_96B4_EE21CA5EB19C__INCLUDED_)
#define AFX_DLGPROXY_H__73C59726_E576_4481_96B4_EE21CA5EB19C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CExecuterDlg;

/////////////////////////////////////////////////////////////////////////////
// CExecuterDlgAutoProxy command target

class CExecuterDlgAutoProxy : public CCmdTarget
{
	DECLARE_DYNCREATE(CExecuterDlgAutoProxy)

	CExecuterDlgAutoProxy();           // protected constructor used by dynamic creation

// Attributes
public:
	CExecuterDlg* m_pDialog;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExecuterDlgAutoProxy)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CExecuterDlgAutoProxy();

	// Generated message map functions
	//{{AFX_MSG(CExecuterDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	DECLARE_OLECREATE(CExecuterDlgAutoProxy)

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CExecuterDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPROXY_H__73C59726_E576_4481_96B4_EE21CA5EB19C__INCLUDED_)
