// ExecuterDlg.h : header file
//

#if !defined(AFX_EXECUTERDLG_H__12E43796_2D88_40DE_8785_3D9AF6F1A623__INCLUDED_)
#define AFX_EXECUTERDLG_H__12E43796_2D88_40DE_8785_3D9AF6F1A623__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CExecuterDlgAutoProxy;

/////////////////////////////////////////////////////////////////////////////
// CExecuterDlg dialog

class CExecuterDlg : public CDialog
{
	DECLARE_DYNAMIC(CExecuterDlg);
	friend class CExecuterDlgAutoProxy;

// Construction
public:
	CExecuterDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CExecuterDlg();

// Dialog Data
	//{{AFX_DATA(CExecuterDlg)
	enum { IDD = IDD_EXECUTER_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExecuterDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CExecuterDlgAutoProxy* m_pAutoProxy;
	HICON m_hIcon;

	BOOL CanExit();

	// Generated message map functions
	//{{AFX_MSG(CExecuterDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXECUTERDLG_H__12E43796_2D88_40DE_8785_3D9AF6F1A623__INCLUDED_)
