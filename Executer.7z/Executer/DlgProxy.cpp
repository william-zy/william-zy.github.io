// DlgProxy.cpp : implementation file
//

#include "stdafx.h"
#include "Executer.h"
#include "DlgProxy.h"
#include "ExecuterDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CExecuterDlgAutoProxy

IMPLEMENT_DYNCREATE(CExecuterDlgAutoProxy, CCmdTarget)

CExecuterDlgAutoProxy::CExecuterDlgAutoProxy()
{
	EnableAutomation();
	
	// To keep the application running as long as an automation 
	//	object is active, the constructor calls AfxOleLockApp.
	AfxOleLockApp();

	// Get access to the dialog through the application's
	//  main window pointer.  Set the proxy's internal pointer
	//  to point to the dialog, and set the dialog's back pointer to
	//  this proxy.
	ASSERT (AfxGetApp()->m_pMainWnd != NULL);
	ASSERT_VALID (AfxGetApp()->m_pMainWnd);
	ASSERT_KINDOF(CExecuterDlg, AfxGetApp()->m_pMainWnd);
	m_pDialog = (CExecuterDlg*) AfxGetApp()->m_pMainWnd;
	m_pDialog->m_pAutoProxy = this;
}

CExecuterDlgAutoProxy::~CExecuterDlgAutoProxy()
{
	// To terminate the application when all objects created with
	// 	with automation, the destructor calls AfxOleUnlockApp.
	//  Among other things, this will destroy the main dialog
	if (m_pDialog != NULL)
		m_pDialog->m_pAutoProxy = NULL;
	AfxOleUnlockApp();
}

void CExecuterDlgAutoProxy::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CExecuterDlgAutoProxy, CCmdTarget)
	//{{AFX_MSG_MAP(CExecuterDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CExecuterDlgAutoProxy, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CExecuterDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IExecuter to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {E4699304-49AC-4B7A-ACF9-398CF9F8893F}
static const IID IID_IExecuter =
{ 0xe4699304, 0x49ac, 0x4b7a, { 0xac, 0xf9, 0x39, 0x8c, 0xf9, 0xf8, 0x89, 0x3f } };

BEGIN_INTERFACE_MAP(CExecuterDlgAutoProxy, CCmdTarget)
	INTERFACE_PART(CExecuterDlgAutoProxy, IID_IExecuter, Dispatch)
END_INTERFACE_MAP()

// The IMPLEMENT_OLECREATE2 macro is defined in StdAfx.h of this project
// {A980D347-7749-4053-AB97-89D33C5D3973}
IMPLEMENT_OLECREATE2(CExecuterDlgAutoProxy, "Executer.Application", 0xa980d347, 0x7749, 0x4053, 0xab, 0x97, 0x89, 0xd3, 0x3c, 0x5d, 0x39, 0x73)

/////////////////////////////////////////////////////////////////////////////
// CExecuterDlgAutoProxy message handlers
