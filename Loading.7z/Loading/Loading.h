// Loading.h : main header file for the LOADING application
//

#if !defined(AFX_LOADING_H__FD9295A8_76BA_449A_A944_3C82BD45B283__INCLUDED_)
#define AFX_LOADING_H__FD9295A8_76BA_449A_A944_3C82BD45B283__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CLoadingApp:
// See Loading.cpp for the implementation of this class
//

class CLoadingApp : public CWinApp
{
public:
	CLoadingApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLoadingApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CLoadingApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOADING_H__FD9295A8_76BA_449A_A944_3C82BD45B283__INCLUDED_)
