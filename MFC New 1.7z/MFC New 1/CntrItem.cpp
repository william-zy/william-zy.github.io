// CntrItem.cpp : implementation of the CMFCNew1CntrItem class
//

#include "stdafx.h"
#include "MFC New 1.h"

#include "MFC New 1Doc.h"
#include "MFC New 1View.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMFCNew1CntrItem implementation

IMPLEMENT_SERIAL(CMFCNew1CntrItem, CRichEditCntrItem, 0)

CMFCNew1CntrItem::CMFCNew1CntrItem(REOBJECT* preo, CMFCNew1Doc* pContainer)
	: CRichEditCntrItem(preo, pContainer)
{
	// TODO: add one-time construction code here
	
}

CMFCNew1CntrItem::~CMFCNew1CntrItem()
{
	// TODO: add cleanup code here
	
}

/////////////////////////////////////////////////////////////////////////////
// CMFCNew1CntrItem diagnostics

#ifdef _DEBUG
void CMFCNew1CntrItem::AssertValid() const
{
	CRichEditCntrItem::AssertValid();
}

void CMFCNew1CntrItem::Dump(CDumpContext& dc) const
{
	CRichEditCntrItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////
