// CntrItem.h : interface of the CMFCNew1CntrItem class
//

#if !defined(AFX_CNTRITEM_H__C1843B1F_3EFB_45EC_BD6D_1EF0A5698DE3__INCLUDED_)
#define AFX_CNTRITEM_H__C1843B1F_3EFB_45EC_BD6D_1EF0A5698DE3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMFCNew1Doc;
class CMFCNew1View;

class CMFCNew1CntrItem : public CRichEditCntrItem
{
	DECLARE_SERIAL(CMFCNew1CntrItem)

// Constructors
public:
	CMFCNew1CntrItem(REOBJECT* preo = NULL, CMFCNew1Doc* pContainer = NULL);
		// Note: pContainer is allowed to be NULL to enable IMPLEMENT_SERIALIZE.
		//  IMPLEMENT_SERIALIZE requires the class have a constructor with
		//  zero arguments.  Normally, OLE items are constructed with a
		//  non-NULL document pointer.

// Attributes
public:
	CMFCNew1Doc* GetDocument()
		{ return (CMFCNew1Doc*)CRichEditCntrItem::GetDocument(); }
	CMFCNew1View* GetActiveView()
		{ return (CMFCNew1View*)CRichEditCntrItem::GetActiveView(); }

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCNew1CntrItem)
	public:
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	~CMFCNew1CntrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CNTRITEM_H__C1843B1F_3EFB_45EC_BD6D_1EF0A5698DE3__INCLUDED_)
