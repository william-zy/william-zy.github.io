// MFC New 1View.h : interface of the CMFCNew1View class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MFCNEW1VIEW_H__18D50960_37C0_4F83_AB57_B71631F34D4E__INCLUDED_)
#define AFX_MFCNEW1VIEW_H__18D50960_37C0_4F83_AB57_B71631F34D4E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMFCNew1CntrItem;

class CMFCNew1View : public CRichEditView
{
protected: // create from serialization only
	CMFCNew1View();
	DECLARE_DYNCREATE(CMFCNew1View)

// Attributes
public:
	CMFCNew1Doc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCNew1View)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMFCNew1View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMFCNew1View)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MFC New 1View.cpp
inline CMFCNew1Doc* CMFCNew1View::GetDocument()
   { return (CMFCNew1Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCNEW1VIEW_H__18D50960_37C0_4F83_AB57_B71631F34D4E__INCLUDED_)
