// DlgProxy.h : header file
//

#if !defined(AFX_DLGPROXY_H__CA5CCF97_B88C_48F9_A83B_E90FFBB724EC__INCLUDED_)
#define AFX_DLGPROXY_H__CA5CCF97_B88C_48F9_A83B_E90FFBB724EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMFCProjectIIIDlg;

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectIIIDlgAutoProxy command target

class CMFCProjectIIIDlgAutoProxy : public CCmdTarget
{
	DECLARE_DYNCREATE(CMFCProjectIIIDlgAutoProxy)

	CMFCProjectIIIDlgAutoProxy();           // protected constructor used by dynamic creation

// Attributes
public:
	CMFCProjectIIIDlg* m_pDialog;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCProjectIIIDlgAutoProxy)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMFCProjectIIIDlgAutoProxy();

	// Generated message map functions
	//{{AFX_MSG(CMFCProjectIIIDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	DECLARE_OLECREATE(CMFCProjectIIIDlgAutoProxy)

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CMFCProjectIIIDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPROXY_H__CA5CCF97_B88C_48F9_A83B_E90FFBB724EC__INCLUDED_)
