// MFCProject IIIDlg.h : header file
//

#if !defined(AFX_MFCPROJECTIIIDLG_H__92AFA9BE_7403_42B6_873C_5C2410C1AAB3__INCLUDED_)
#define AFX_MFCPROJECTIIIDLG_H__92AFA9BE_7403_42B6_873C_5C2410C1AAB3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMFCProjectIIIDlgAutoProxy;

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectIIIDlg dialog

class CMFCProjectIIIDlg : public CDialog
{
	DECLARE_DYNAMIC(CMFCProjectIIIDlg);
	friend class CMFCProjectIIIDlgAutoProxy;

// Construction
public:
	CMFCProjectIIIDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CMFCProjectIIIDlg();

// Dialog Data
	//{{AFX_DATA(CMFCProjectIIIDlg)
	enum { IDD = IDD_MFCPROJECTIII_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCProjectIIIDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CMFCProjectIIIDlgAutoProxy* m_pAutoProxy;
	HICON m_hIcon;

	BOOL CanExit();

	// Generated message map functions
	//{{AFX_MSG(CMFCProjectIIIDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCPROJECTIIIDLG_H__92AFA9BE_7403_42B6_873C_5C2410C1AAB3__INCLUDED_)
