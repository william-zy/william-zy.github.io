#if !defined(AFX_READY_H__F776990B_EBEB_4BE6_88E8_9D60A7FB0C1C__INCLUDED_)
#define AFX_READY_H__F776990B_EBEB_4BE6_88E8_9D60A7FB0C1C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Ready.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Ready dialog

class Ready : public CDialog
{
// Construction
public:
	Ready(CWnd* pParent = NULL);   // standard constructor
	int usr,tgt;
	bool isi;
	CString Name;
// Dialog Data
	//{{AFX_DATA(Ready)
	enum { IDD = IDD_CHECK_READY };
	CComboBox	m_cb1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Ready)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(Ready)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeEdit1();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_READY_H__F776990B_EBEB_4BE6_88E8_9D60A7FB0C1C__INCLUDED_)
