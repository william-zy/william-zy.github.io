#if !defined(AFX_MAINDLG_H__353A64C1_B769_4036_A9B7_90621A637CB5__INCLUDED_)
#define AFX_MAINDLG_H__353A64C1_B769_4036_A9B7_90621A637CB5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MainDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// MainDlg dialog

class MainDlg : public CDialog
{
// Construction
public:
	MainDlg(CWnd* pParent = NULL);   // standard constructor
	int nId;
	BOOL is3ban;
// Dialog Data
	//{{AFX_DATA(MainDlg)
	enum { IDD = IDD_MAIN };
	CTabCtrl	m_tab;
	CComboBox	m_target;
	CComboBox	m_user;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(MainDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(MainDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnEditchangeUser();
	afx_msg void OnEditchangeTarget();
	afx_msg void OnChangeEdit1();
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnButton1();
	afx_msg void OnCheckl();
	afx_msg void OnStatic4();
	afx_msg void OnButtonBGCP();
	afx_msg void OnButtonMianZe();
	afx_msg void OnButton6();
	afx_msg void OnButton7();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINDLG_H__353A64C1_B769_4036_A9B7_90621A637CB5__INCLUDED_)
