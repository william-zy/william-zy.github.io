// ListDlg.cpp : implementation file
//

#include "stdafx.h"
#include "��ϵ��֤ʵ�ó���.h"
#include "ListDlg.h"
#include "Name.h"
extern fFind name;
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ListDlg dialog


ListDlg::ListDlg(CWnd* pParent /*=NULL*/)
	: CDialog(ListDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(ListDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void ListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ListDlg)
	DDX_Control(pDX, IDC_LIST1, m_list);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ListDlg, CDialog)
	//{{AFX_MSG_MAP(ListDlg)
	ON_NOTIFY(NM_CLICK, IDC_LIST1, OnClickList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ListDlg message handlers

void ListDlg::OnClickList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

BOOL ListDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	int i=0;
	m_list.ModifyStyle(0,LVS_REPORT);
	m_list.InsertColumn(i,"����");
	m_list.SetColumnWidth(i++,90);
	m_list.InsertColumn(i,"ѧ��");
	m_list.SetColumnWidth(i++,50);
	m_list.InsertColumn(i,"�Ա�");
	m_list.SetColumnWidth(i++,50);
	for(i=1;i<=38;i++){
		m_list.InsertItem(i-1,name[i]);
		CString str;
		str.Format("%d",i);
		m_list.SetItemText(i-1,1,str);
		m_list.SetItemText(i-1,2,i>13?"��":"Ů");
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
