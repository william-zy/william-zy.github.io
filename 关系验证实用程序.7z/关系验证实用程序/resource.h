//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ��ϵ��֤ʵ�ó���.rc
//
#define IDD_MY_DIALOG                   102
#define IDD_BASIN                       102
#define IDR_MAINFRAME                   128
#define IDD_LOGINDLG                    129
#define IDD_MAIN                        130
#define IDD_LIST                        131
#define IDD_CHECK_READY                 132
#define IDC_PASS                        1000
#define IDC_USR                         1001
#define IDC_USER                        1003
#define IDC_TARGET                      1004
#define IDC_CHECKL                      1005
#define IDC_EDIT1                       1007
#define IDC_BUTTON1                     1008
#define IDC_BUTTON3                     1012
#define IDC_BUTTON4                     1016
#define IDC_BUTTON5                     1017
#define IDC_BUTTON6                     1018
#define IDC_LIST1                       1019
#define IDC_STATICU                     1022
#define IDC_STATICT                     1023
#define IDC_BUTTON7                     1024
#define IDC_COMBO1                      1025
#define IDC_RADIO1                      1026
#define IDC_RADIO2                      1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
