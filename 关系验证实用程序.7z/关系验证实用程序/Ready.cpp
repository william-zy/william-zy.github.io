// Ready.cpp : implementation file
//

#include "stdafx.h"
#include "��ϵ��֤ʵ�ó���.h"
#include "Ready.h"
#include "Name.h"
extern fFind name;
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Ready dialog


Ready::Ready(CWnd* pParent /*=NULL*/)
	: CDialog(Ready::IDD, pParent)
{
	//{{AFX_DATA_INIT(Ready)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void Ready::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Ready)
	DDX_Control(pDX, IDC_COMBO1, m_cb1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Ready, CDialog)
	//{{AFX_MSG_MAP(Ready)
	ON_EN_CHANGE(IDC_EDIT1, OnChangeEdit1)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Ready message handlers

BOOL Ready::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CString Usr;
	if(isi)
		Usr.Format("3��%d��",usr);
	else Usr.Format("%d�� - \"%s\"",usr,name[usr]);
	SetDlgItemText(IDC_STATICU,Usr);
	Usr.Format("%d�� - \"%s\"",tgt,name[tgt]);
	SetDlgItemText(IDC_STATICT,Usr);
	Usr.Format("����:%s",Name);
	SetDlgItemText(IDC_EDIT1,Usr);
	m_cb1.InsertString(0,"CP");
	m_cb1.InsertString(0,"ƽ��deCP");
	m_cb1.InsertString(0,"ƽ��");
	m_cb1.InsertString(0,"�й���");
	((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(1);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void Ready::OnChangeEdit1() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	
}

void Ready::OnRadio1() 
{
	// TODO: Add your control notification handler code here
	m_cb1.EnableWindow(1);
}

void Ready::OnRadio2() 
{
	// TODO: Add your control notification handler code here
	m_cb1.EnableWindow(0);
}
