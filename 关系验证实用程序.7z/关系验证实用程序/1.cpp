#include "Name.h"
fFind name(1);