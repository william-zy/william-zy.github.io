// LoginDlg.cpp : implementation file
//

#include "stdafx.h"
#include "��ϵ��֤ʵ�ó���.h"
#include "LoginDlg.h"
#include "Name.h"
extern fFind name;
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// LoginDlg dialog


LoginDlg::LoginDlg(CWnd* pParent /*=NULL*/)
	: CDialog(LoginDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(LoginDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void LoginDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(LoginDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(LoginDlg, CDialog)
	//{{AFX_MSG_MAP(LoginDlg)
	ON_EN_CHANGE(IDC_USR, OnChangeUsr)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// LoginDlg message handlers

void LoginDlg::OnOK() 
{
	// TODO: Add extra validation here
	CString str;
	GetDlgItemText(IDC_USR,str);
	int n=
	GetDlgItemInt(IDC_PASS);
	if(n==name.WholeFind(str))
	MessageBox("��¼�ɹ�!�û���:"+str,"",MB_ICONINFORMATION),nId=n,CDialog::OnOK();
	else MessageBox("��¼ʧ��!","",MB_ICONERROR);
}

void LoginDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

void LoginDlg::OnChangeUsr() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	
}

BOOL LoginDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	SetDlgItemText(IDC_USR,"�û���");
	SetDlgItemText(IDC_PASS,"����");
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
