// CntrItem.h : interface of the CMFCProjectVCntrItem class
//

#if !defined(AFX_CNTRITEM_H__65B4C9F1_9613_4A0D_AE48_3F517F02D82A__INCLUDED_)
#define AFX_CNTRITEM_H__65B4C9F1_9613_4A0D_AE48_3F517F02D82A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMFCProjectVDoc;
class CMFCProjectVView;

class CMFCProjectVCntrItem : public CRichEditCntrItem
{
	DECLARE_SERIAL(CMFCProjectVCntrItem)

// Constructors
public:
	CMFCProjectVCntrItem(REOBJECT* preo = NULL, CMFCProjectVDoc* pContainer = NULL);
		// Note: pContainer is allowed to be NULL to enable IMPLEMENT_SERIALIZE.
		//  IMPLEMENT_SERIALIZE requires the class have a constructor with
		//  zero arguments.  Normally, OLE items are constructed with a
		//  non-NULL document pointer.

// Attributes
public:
	CMFCProjectVDoc* GetDocument()
		{ return (CMFCProjectVDoc*)CRichEditCntrItem::GetDocument(); }
	CMFCProjectVView* GetActiveView()
		{ return (CMFCProjectVView*)CRichEditCntrItem::GetActiveView(); }

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCProjectVCntrItem)
	public:
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	~CMFCProjectVCntrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CNTRITEM_H__65B4C9F1_9613_4A0D_AE48_3F517F02D82A__INCLUDED_)
