// MFCProject VView.h : interface of the CMFCProjectVView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MFCPROJECTVVIEW_H__DFBA1ECB_2340_4EAC_A365_2E4657B39FBD__INCLUDED_)
#define AFX_MFCPROJECTVVIEW_H__DFBA1ECB_2340_4EAC_A365_2E4657B39FBD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMFCProjectVCntrItem;

class CMFCProjectVView : public CRichEditView
{
protected: // create from serialization only
	CMFCProjectVView();
	DECLARE_DYNCREATE(CMFCProjectVView)

// Attributes
public:
	CMFCProjectVDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCProjectVView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMFCProjectVView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMFCProjectVView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MFCProject VView.cpp
inline CMFCProjectVDoc* CMFCProjectVView::GetDocument()
   { return (CMFCProjectVDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCPROJECTVVIEW_H__DFBA1ECB_2340_4EAC_A365_2E4657B39FBD__INCLUDED_)
