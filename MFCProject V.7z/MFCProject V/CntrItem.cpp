// CntrItem.cpp : implementation of the CMFCProjectVCntrItem class
//

#include "stdafx.h"
#include "MFCProject V.h"

#include "MFCProject VDoc.h"
#include "MFCProject VView.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectVCntrItem implementation

IMPLEMENT_SERIAL(CMFCProjectVCntrItem, CRichEditCntrItem, 0)

CMFCProjectVCntrItem::CMFCProjectVCntrItem(REOBJECT* preo, CMFCProjectVDoc* pContainer)
	: CRichEditCntrItem(preo, pContainer)
{
	// TODO: add one-time construction code here
	
}

CMFCProjectVCntrItem::~CMFCProjectVCntrItem()
{
	// TODO: add cleanup code here
	
}

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectVCntrItem diagnostics

#ifdef _DEBUG
void CMFCProjectVCntrItem::AssertValid() const
{
	CRichEditCntrItem::AssertValid();
}

void CMFCProjectVCntrItem::Dump(CDumpContext& dc) const
{
	CRichEditCntrItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////
