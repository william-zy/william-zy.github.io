// MFCProject VDoc.cpp : implementation of the CMFCProjectVDoc class
//

#include "stdafx.h"
#include "MFCProject V.h"

#include "MFCProject VDoc.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectVDoc

IMPLEMENT_DYNCREATE(CMFCProjectVDoc, CRichEditDoc)

BEGIN_MESSAGE_MAP(CMFCProjectVDoc, CRichEditDoc)
	//{{AFX_MSG_MAP(CMFCProjectVDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Enable default OLE container implementation
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_LINKS, CRichEditDoc::OnUpdateEditLinksMenu)
	ON_COMMAND(ID_OLE_EDIT_LINKS, CRichEditDoc::OnEditLinks)
	ON_UPDATE_COMMAND_UI_RANGE(ID_OLE_VERB_FIRST, ID_OLE_VERB_LAST, CRichEditDoc::OnUpdateObjectVerbMenu)
	ON_COMMAND(ID_FILE_SEND_MAIL, OnFileSendMail)
	ON_UPDATE_COMMAND_UI(ID_FILE_SEND_MAIL, OnUpdateFileSendMail)
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CMFCProjectVDoc, CRichEditDoc)
	//{{AFX_DISPATCH_MAP(CMFCProjectVDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//      DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IMFCProjectV to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {A567A66A-A8FA-4464-85B3-80476A4CEEFB}
static const IID IID_IMFCProjectV =
{ 0xa567a66a, 0xa8fa, 0x4464, { 0x85, 0xb3, 0x80, 0x47, 0x6a, 0x4c, 0xee, 0xfb } };

BEGIN_INTERFACE_MAP(CMFCProjectVDoc, CRichEditDoc)
	INTERFACE_PART(CMFCProjectVDoc, IID_IMFCProjectV, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectVDoc construction/destruction

CMFCProjectVDoc::CMFCProjectVDoc()
{
	// Use OLE compound files
	EnableCompoundFile();

	// TODO: add one-time construction code here

	EnableAutomation();

	AfxOleLockApp();
}

CMFCProjectVDoc::~CMFCProjectVDoc()
{
	AfxOleUnlockApp();
}

BOOL CMFCProjectVDoc::OnNewDocument()
{
	if (!CRichEditDoc::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

CRichEditCntrItem* CMFCProjectVDoc::CreateClientItem(REOBJECT* preo) const
{
	// cast away constness of this
	return new CMFCProjectVCntrItem(preo, (CMFCProjectVDoc*) this);
}



/////////////////////////////////////////////////////////////////////////////
// CMFCProjectVDoc serialization

void CMFCProjectVDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}

	// Calling the base class CRichEditDoc enables serialization
	//  of the container document's COleClientItem objects.
	// TODO: set CRichEditDoc::m_bRTF = FALSE if you are serializing as text
	CRichEditDoc::Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectVDoc diagnostics

#ifdef _DEBUG
void CMFCProjectVDoc::AssertValid() const
{
	CRichEditDoc::AssertValid();
}

void CMFCProjectVDoc::Dump(CDumpContext& dc) const
{
	CRichEditDoc::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectVDoc commands
