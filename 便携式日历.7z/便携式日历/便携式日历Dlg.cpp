// ��Яʽ����Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "��Яʽ����.h"
#include "��Яʽ����Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyDlg dialog

CMyDlg::CMyDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyDlg)
	aa = _T("");
	calendar = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyDlg)
	DDX_Control(pDX, IDC_BUTTON1, easy);
	DDX_Control(pDX, IDC_DATETIMEPICKER1, picked);
	DDX_Control(pDX, IDC_DATETIMEPICKER2, curr);
	DDX_Control(pDX, IDC_COMBO1, type);
	DDX_Text(pDX, IDC_EDIT1, aa);
	DDX_MonthCalCtrl(pDX, IDC_MONTHCALENDAR1, calendar);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMyDlg, CDialog)
	//{{AFX_MSG_MAP(CMyDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_CBN_SELCHANGE(IDC_COMBO1, OnSelchangeCombo1)
	ON_EN_CHANGE(IDC_EDIT1, OnChangeEdit1)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyDlg message handlers

BOOL CMyDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	type.InsertString(0,"�Զ���...");
	type.InsertString(0,"hh:mm:ss");
	type.InsertString(0,"HH:mm:ss");
	type.InsertString(0,"yyyy-MM-dd");
	type.InsertString(0,"yyyyMMddHHmmss");
	type.InsertString(0,"yyyy-MM-dd HH:mm");
	type.InsertString(0,"yyyy-MM-dd hh:mm:ss");
	type.InsertString(0,"yyyy-MM-dd HH:mm:ss");
	type.SelectString(-1,"yyyy-MM-dd HH:mm:ss");
	OnSelchangeCombo1();
	calendar.operator=(time(0));
	UpdateData(0);
	SetTimer(100,100,NULL);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMyDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMyDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMyDlg::OnOK() 
{
	// TODO: Add extra validation here
	KillTimer(100);
	CDialog::OnOK();
}
bool Easy;
void CMyDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	Easy=!Easy;
	type.ShowWindow(!Easy);
	easy.SetWindowText(Easy?"�˳����ģʽ":"���ģʽ");
	GetDlgItem(IDC_STATIC1)->ShowWindow(!Easy);
	GetDlgItem(IDC_EDIT1)->ShowWindow(!Easy);
	OnSelchangeCombo1();
}

void CMyDlg::OnSelchangeCombo1() 
{
	// TODO: Add your control notification handler code here
	if(type.GetCurSel()!=7){
		CString str;
		type.GetWindowText(str);
		curr.SetFormat(str);
		GetDlgItem(IDC_STATIC1)->ShowWindow(0);
		GetDlgItem(IDC_EDIT1)->ShowWindow(0);
	}
	else{
		GetDlgItem(IDC_STATIC1)->ShowWindow(1);
		GetDlgItem(IDC_EDIT1)->ShowWindow(1);
		char str[1000]={0};
		GetDlgItemText(IDC_EDIT1,str,1000);
		curr.SetFormat(str);
	}
}

void CMyDlg::OnChangeEdit1() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	OnSelchangeCombo1();
}

void CMyDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	CTime time=CTime::GetCurrentTime();
	OnSelchangeCombo1();
	curr.SetTime(&time);
	UpdateData();
	picked.SetTime(&calendar);
	CDialog::OnTimer(nIDEvent);
}
