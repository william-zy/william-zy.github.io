// MFCProject IDoc.cpp : implementation of the CMFCProjectIDoc class
//

#include "stdafx.h"
#include "MFCProject I.h"

#include "MFCProject IDoc.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectIDoc

IMPLEMENT_DYNCREATE(CMFCProjectIDoc, COleDocument)

BEGIN_MESSAGE_MAP(CMFCProjectIDoc, COleDocument)
	//{{AFX_MSG_MAP(CMFCProjectIDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Enable default OLE container implementation
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, COleDocument::OnUpdatePasteMenu)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE_LINK, COleDocument::OnUpdatePasteLinkMenu)
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_CONVERT, COleDocument::OnUpdateObjectVerbMenu)
	ON_COMMAND(ID_OLE_EDIT_CONVERT, COleDocument::OnEditConvert)
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_LINKS, COleDocument::OnUpdateEditLinksMenu)
	ON_COMMAND(ID_OLE_EDIT_LINKS, COleDocument::OnEditLinks)
	ON_UPDATE_COMMAND_UI_RANGE(ID_OLE_VERB_FIRST, ID_OLE_VERB_LAST, COleDocument::OnUpdateObjectVerbMenu)
	ON_COMMAND(ID_FILE_SEND_MAIL, OnFileSendMail)
	ON_UPDATE_COMMAND_UI(ID_FILE_SEND_MAIL, OnUpdateFileSendMail)
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CMFCProjectIDoc, COleDocument)
	//{{AFX_DISPATCH_MAP(CMFCProjectIDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//      DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IMFCProjectI to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {CA28042D-22F5-430F-A81D-AEF0AC9FC90F}
static const IID IID_IMFCProjectI =
{ 0xca28042d, 0x22f5, 0x430f, { 0xa8, 0x1d, 0xae, 0xf0, 0xac, 0x9f, 0xc9, 0xf } };

BEGIN_INTERFACE_MAP(CMFCProjectIDoc, COleDocument)
	INTERFACE_PART(CMFCProjectIDoc, IID_IMFCProjectI, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectIDoc construction/destruction

CMFCProjectIDoc::CMFCProjectIDoc()
{
	// Use OLE compound files
	EnableCompoundFile();

	// TODO: add one-time construction code here

	EnableAutomation();

	AfxOleLockApp();
}

CMFCProjectIDoc::~CMFCProjectIDoc()
{
	AfxOleUnlockApp();
}

BOOL CMFCProjectIDoc::OnNewDocument()
{
	if (!COleDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMFCProjectIDoc serialization

void CMFCProjectIDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}

	// Calling the base class COleDocument enables serialization
	//  of the container document's COleClientItem objects.
	COleDocument::Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectIDoc diagnostics

#ifdef _DEBUG
void CMFCProjectIDoc::AssertValid() const
{
	COleDocument::AssertValid();
}

void CMFCProjectIDoc::Dump(CDumpContext& dc) const
{
	COleDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectIDoc commands
