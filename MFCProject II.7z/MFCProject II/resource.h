//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MFCProject II.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_ABOUTBOX                    101
#define IDD_MFCPROJECTII_DIALOG         102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_BUTTON1                     1002
#define IDC_PROGRESS1                   1006
#define IDC_MONTHCALENDAR1              1009
#define IDC_DATETIMEPICKER1             1012
#define IDC_HOTKEY1                     1013
#define IDC_TAB1                        1016
#define IDC_COMBO1                      1017
#define IDC_CHECK1                      1018
#define IDC_RADIO1                      1019
#define IDC_RADIO2                      1020
#define IDC_RADIO3                      1021
#define IDC_SLIDER2                     1023
#define IDC_PROGCTRL1                   1024
#define IDC_LIST2                       1026
#define IDC_ANIMATE2                    1027
#define IDC_LIST3                       1028
#define IDC_IPADDRESS1                  1030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
