// DlgProxy.h : header file
//

#if !defined(AFX_DLGPROXY_H__21342352_1FFE_44A9_8E24_6168D983125C__INCLUDED_)
#define AFX_DLGPROXY_H__21342352_1FFE_44A9_8E24_6168D983125C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMFCProjectIIDlg;

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectIIDlgAutoProxy command target

class CMFCProjectIIDlgAutoProxy : public CCmdTarget
{
	DECLARE_DYNCREATE(CMFCProjectIIDlgAutoProxy)

	CMFCProjectIIDlgAutoProxy();           // protected constructor used by dynamic creation

// Attributes
public:
	CMFCProjectIIDlg* m_pDialog;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCProjectIIDlgAutoProxy)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMFCProjectIIDlgAutoProxy();

	// Generated message map functions
	//{{AFX_MSG(CMFCProjectIIDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	DECLARE_OLECREATE(CMFCProjectIIDlgAutoProxy)

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CMFCProjectIIDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPROXY_H__21342352_1FFE_44A9_8E24_6168D983125C__INCLUDED_)
