// DlgProxy.cpp : implementation file
//

#include "stdafx.h"
#include "MFCProject II.h"
#include "DlgProxy.h"
#include "MFCProject IIDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectIIDlgAutoProxy

IMPLEMENT_DYNCREATE(CMFCProjectIIDlgAutoProxy, CCmdTarget)

CMFCProjectIIDlgAutoProxy::CMFCProjectIIDlgAutoProxy()
{
	EnableAutomation();
	
	// To keep the application running as long as an automation 
	//	object is active, the constructor calls AfxOleLockApp.
	AfxOleLockApp();

	// Get access to the dialog through the application's
	//  main window pointer.  Set the proxy's internal pointer
	//  to point to the dialog, and set the dialog's back pointer to
	//  this proxy.
	ASSERT (AfxGetApp()->m_pMainWnd != NULL);
	ASSERT_VALID (AfxGetApp()->m_pMainWnd);
	ASSERT_KINDOF(CMFCProjectIIDlg, AfxGetApp()->m_pMainWnd);
	m_pDialog = (CMFCProjectIIDlg*) AfxGetApp()->m_pMainWnd;
	m_pDialog->m_pAutoProxy = this;
}

CMFCProjectIIDlgAutoProxy::~CMFCProjectIIDlgAutoProxy()
{
	// To terminate the application when all objects created with
	// 	with automation, the destructor calls AfxOleUnlockApp.
	//  Among other things, this will destroy the main dialog
	if (m_pDialog != NULL)
		m_pDialog->m_pAutoProxy = NULL;
	AfxOleUnlockApp();
}

void CMFCProjectIIDlgAutoProxy::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CMFCProjectIIDlgAutoProxy, CCmdTarget)
	//{{AFX_MSG_MAP(CMFCProjectIIDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CMFCProjectIIDlgAutoProxy, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CMFCProjectIIDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IMFCProjectII to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {8DED6358-C637-45BB-AA8E-1657FA1F1AA6}
static const IID IID_IMFCProjectII =
{ 0x8ded6358, 0xc637, 0x45bb, { 0xaa, 0x8e, 0x16, 0x57, 0xfa, 0x1f, 0x1a, 0xa6 } };

BEGIN_INTERFACE_MAP(CMFCProjectIIDlgAutoProxy, CCmdTarget)
	INTERFACE_PART(CMFCProjectIIDlgAutoProxy, IID_IMFCProjectII, Dispatch)
END_INTERFACE_MAP()

// The IMPLEMENT_OLECREATE2 macro is defined in StdAfx.h of this project
// {BB823A1B-33C7-4CB7-9284-758E0F4B6D44}
IMPLEMENT_OLECREATE2(CMFCProjectIIDlgAutoProxy, "MFCProjectII.Application", 0xbb823a1b, 0x33c7, 0x4cb7, 0x92, 0x84, 0x75, 0x8e, 0xf, 0x4b, 0x6d, 0x44)

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectIIDlgAutoProxy message handlers
