// MFCProject IIDlg.h : header file
//

#if !defined(AFX_MFCPROJECTIIDLG_H__1E8A2520_F07D_4119_BB33_A729D48D1C3C__INCLUDED_)
#define AFX_MFCPROJECTIIDLG_H__1E8A2520_F07D_4119_BB33_A729D48D1C3C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMFCProjectIIDlgAutoProxy;

/////////////////////////////////////////////////////////////////////////////
// CMFCProjectIIDlg dialog

class CMFCProjectIIDlg : public CDialog
{
	DECLARE_DYNAMIC(CMFCProjectIIDlg);
	friend class CMFCProjectIIDlgAutoProxy;

// Construction
public:
	CMFCProjectIIDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CMFCProjectIIDlg();

// Dialog Data
	//{{AFX_DATA(CMFCProjectIIDlg)
	enum { IDD = IDD_MFCPROJECTII_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCProjectIIDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CMFCProjectIIDlgAutoProxy* m_pAutoProxy;
	HICON m_hIcon;

	BOOL CanExit();

	// Generated message map functions
	//{{AFX_MSG(CMFCProjectIIDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnRadio1();
	afx_msg void OnOutofmemorySlider1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnOutofmemoryAnimate1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButton1();
	afx_msg void OnClickTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnOutofmemoryProgress1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnOutofmemorySpin1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnGetdaystateMonthcalendar1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickRichedit1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCloseupDatetimepicker1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChangeEdit1();
	afx_msg void OnOutofmemoryHotkey1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEditchangeCombo1();
	afx_msg void OnCheck1();
	afx_msg void OnRadio2();
	afx_msg void OnOutofmemorySlider102(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangeList2();
	afx_msg void OnEditchangeComboboxex1();
	afx_msg void OnFieldchangedIpaddress1(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCPROJECTIIDLG_H__1E8A2520_F07D_4119_BB33_A729D48D1C3C__INCLUDED_)
