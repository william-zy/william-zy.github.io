#include<stdio.h>
#include<stdlib.h>
#include<windows.h>
#include <iostream>
int cnt;
using namespace std;
HANDLE hOut=GetStdHandle(STD_OUTPUT_HANDLE);

int main(int argc,char*argv[]){
    float x,y,a;
    for(y=1.5; y >= -1.5; y-=0.1){
        for(x=1.5; x >= -1.5; x-=0.05){
            a = x*x + y*y - 1;
            putchar(a*a*a - x*x*y*y*y <= 0.0 ? '#' : ' ');
            if(a*a*a - x*x*y*y*y <= 0.0){
            	++cnt;
            	SetConsoleTextAttribute(
				hOut,cnt%0xF+1);//�޸���ɫ
			}
        }
        putchar('\n');
    }
    getchar();
    getchar();
    getchar();
    getchar();
    return 0;
}
